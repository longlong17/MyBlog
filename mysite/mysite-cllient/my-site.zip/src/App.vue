<template>
  <div class="app-container">
    <Layout>
      <template #left>
        <div class="aside">
          <SiteAside />
        </div>
      </template>
      <template #default>
        <div class="main">
          <RouterView />
        </div>
      </template>
    </Layout>
    <ToTop />
  </div>
  
</template>

<script>
import Layout from "./components/Layout/";
import SiteAside from "./components/SiteAside/";
import ToTop from "@/components/toTop";
export default {
  components: {
    Layout,
    SiteAside,
    ToTop,
  },
};
</script>

<style lang="less" scoped>
@import "./style/mixin.less";
.app-container {
  .self-fill(fixed);
}
.main {
  width: 100%;
  height: 100%;
}
.aside {
  width: 250px;
  height: 100%;
}
</style>
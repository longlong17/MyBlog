import axios from 'axios';
import showMessage from '../utils/showMessage';

const int = axios.create();

int.interceptors.response.use(function (resp) {
  if (resp.data.code !== 0) {
    showMessage({
      content: resp.data.msg,
      type: 'error',
    });
  } else {
    return resp.data.data;
  }
});

export default int;

<template>
   <Avatar :url='"https://gimg2.baidu.com/image_search/src=http%3A%2F%2Fp5.itc.cn%2Fimages01%2F20210622%2Fae9f09354d24440789966820035f4742.jpeg&refer=http%3A%2F%2Fp5.itc.cn&app=2002&size=f9999,10000&q=a80&n=0&g=0n&fmt=auto?sec=1660217028&t=5ab8759608b83895bcb76082ea8ee9ae"' :size='500'/>
</template>

<script>
import Avatar from './'
export default {
    components:{
        Avatar,
    }
}
</script>

<style>

</style>
<template>
<div class="text">
  <Menu />
  </div>
</template>

<script>
import Menu from './index.vue';
import "@/style/global.less";
export default {
   components   :{
    Menu,
   }
}
</script>

<style>
  .text{
    width: 250px;
    height: 400px;
    background: rgb(32, 32, 31);
  }
</style>
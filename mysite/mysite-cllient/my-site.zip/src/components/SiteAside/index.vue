<template>
  <div class="SiteAside">
    <template v-if="data">
      <Avatar class="SiteAside-Avatar" :url="data.avatar" />
      <h1 class="title">{{ data.siteTitle }}</h1>
    </template>
     <div class="SiteAside-Menu">
        <Menu />
     </div>
     <div class="SiteAside-Contact" v-if="data">
        <Contact />
     </div>
      <p v-if="data" class="footer">
      {{ data.icp }}
    </p>
  </div>
</template>
 
<script>
import Avatar from '../Avatar/index.vue';   //头像组件
import Menu from './Menu' ;   //导航条
import Contact from './Contact';  //练习方式
import { computed } from 'vue';
import {mapState} from "vuex"
export default {
   components: {
    Avatar,
    Menu,
    Contact,
   },
   computed : mapState("setting",["data"])
}
</script>

<style>
 .SiteAside{
    width: 100%;
    height: 100%;
    background: #20201f;
    box-sizing: border-box;
    padding: 10px 0;
    overflow-y: auto;
 }
 .SiteAside-Avatar{
   width: 150px;
   height: 150px;
   margin: 0 auto;
   margin-bottom: 10px;
 }
 .title {
  font-size: 1.2em;
  color: #fff;
  text-align: center;
}
.footer {
  text-align: center;
  font-size: 12px;
}
</style>
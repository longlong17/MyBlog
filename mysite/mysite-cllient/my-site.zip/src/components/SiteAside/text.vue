<template>
  <div class="div">
    <SiteAside />
  </div>
</template>

<script>
import SiteAside from './'
import '@/style/global.less'
export default {
  components:{
    SiteAside,
  }
}
</script>

<style>
   .div{
    width: 250px;
    height: 100vh;
    
   }
</style>
<template>
     <div>
        <icon :type='"home"' />
            <h1>sdfd</h1>
     </div>
</template>

<script>
import icon from './';
export default {
    components : {
        icon
    }
}
</script>

<style>

</style>
<template>
  <div @click="handleClick" v-show="show" class="to-Top-container">Top</div>
</template>

<script>
export default {
  data() {
    return {
      show: false,
    };
  },
  created() {
    this.$bus.$on("mainScroll", this.handleScroll);
  },
  destroyed() {
    this.$bus.$off("mainScroll", this.handleScroll);
  },
  methods: {
    handleScroll(dom) {
      if (!dom) {
        this.show = false;
        return;
      }
      const resd = 500; //滚动到100的位置出现
      this.show = dom.scrollTop >= resd;
    },
  handleClick() {
    //回到顶部
    this.$bus.$emit('setMainScroll',0)
  },
  },
};
</script>

<style scoped lang ="less">
@import "~@/style/var.less";
.to-Top-container {
  width: 50px;
  height: 50px;
  background: @primary;
  border-radius: 50%;
  line-height: 50px;
  text-align: center;
  position: fixed;
  right: 60px;
  bottom: 40px;
  cursor: pointer;
  color: #fff;
  z-index: 99;
}
</style>
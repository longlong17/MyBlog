import url from '../assets/loading.svg';
import styles from './loading.module.less'
function getLoadingImage(el){
    return el.querySelector('img[data-role=loading]');
}
function createLoadingImg (){
 //创建img 元素家到父容器中
 const img = document.createElement('img');
 img.src = url;
 img.dataset.role = 'loading';
 img.className = styles.loading;
 return img;
}
export default function(el,binding){
  const curImg = getLoadingImage(el);
  if(binding.value) {
    if(!curImg){
        const img = createLoadingImg();
        el.appendChild(img);
    }
  }else{
    if(curImg){
        curImg.remove();
    }
  }
}
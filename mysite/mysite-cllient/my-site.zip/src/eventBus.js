import Vue from "vue";
const app = new Vue({});
/**
 * mainScroll 监听滚动事件 元素dom
 * setMainScroll 当需要设置主区域时触发 滚动条的高度
 */
Vue.prototype.$bus = app;

export default app;
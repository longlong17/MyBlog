// 入口文件
import Vue from 'vue';
import App from './App.vue';
import './style/global.less'; //
import router from './router';  //路由
import showMessage from './utils/showMessage';
// import './mock';
import vloaing from './directives/loading';
import vlazy from './directives/lazy';
import store  from './store'
import './eventBus';
store.dispatch("setting/fetchSetting")
//给vue添加自定义指令
Vue.directive('loaing', vloaing)  //弹出消息框
Vue.directive('lazy',vlazy)   // 图片懒加载
Vue.prototype.$showMessage = showMessage; // 弹出消息框
new Vue({
  router,
  store,
  render: (h) => h(App),
}).$mount('#app');


export default function(defaultDataValue = null){
   return {
    data(){
        return {
            isLoading : true,
            data: defaultDataValue,
        }
    },
    async created(){
       const data = await this.fetchData();
        this.isLoading = false;
        // for(let item of data){
        //     item.thumb = lostURL + item.thumb
        //  
        this.data = data;
    }
   }
}
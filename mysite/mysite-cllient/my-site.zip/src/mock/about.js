import Mock from "mockjs";
Mock.mock("/api/about", "get", {
  code: 0,
  msg: "",
  data: "https://mbd.baidu.com/newspage/data/landingsuper?context=%7B%22nid%22%3A%22news_8826516942479535652%22%7D&n_type=-1&p_from=-1",
});

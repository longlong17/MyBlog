import "./banner";
import "./setting";
import "./project";
import "./about";
import "./blog";
import "./message";
import Mock from "mockjs";
Mock.setup({
  timeout: "1000-2000",
});

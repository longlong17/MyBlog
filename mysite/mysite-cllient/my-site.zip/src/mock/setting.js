import Mock from 'mockjs';
Mock.mock('/api/setting', 'get', {
  code: 0,
  msg: '',
  data: {
    avatar:
      'https://img1.baidu.com/it/u=999074466,1525171260&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660150800&t=7c6c98549ecd73184fd6efb2f5586c80',
    siteTitle: '我的个人空间',
    github: 'https://github.com/DuYi-Edu',
    qq: '3263023350',
    qqQrCode:
      'https://img1.baidu.com/it/u=999074466,1525171260&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660150800&t=7c6c98549ecd73184fd6efb2f5586c80',
    weixin: 'yh777bao',
    weixinQrCode:
      'https://img1.baidu.com/it/u=999074466,1525171260&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660150800&t=7c6c98549ecd73184fd6efb2f5586c80',
    mail: 'duyi@gmail.com',
    icp: '黑ICP备17001719号',
    githubName: 'DuYi-Edu',
    favicon:
      'https://img1.baidu.com/it/u=999074466,1525171260&fm=253&app=138&size=w931&n=0&f=JPEG&fmt=auto?sec=1660150800&t=7c6c98549ecd73184fd6efb2f5586c80',
  },
});

<template>
  <div>
    <h1>refs</h1>
    <h2>这是第二个</h2>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
import { getBanners } from '@/api/banner';
import {lostURL} from "@/URL";
export default {
  namespaced: true, //开启命名空间
  state: {
    // 数据的配置
    loading: false, // 是否在加载中
    data: [], //拿到的数据
  },
  mutations: {
    //提交函数需要改变仓库的数据只能通过提交来改变
    /**
     *
     * 指代当前文件的仓库 state
     * 附和要传的其他信息 payload
     */
    setLoading(state, payload) {
      state.loading = payload;
    },
    setData(state, payload) {
      state.data = payload;
    },
  },
  actions: {
    //凡是异步的操作都要放到这里
    /**
     *
     * 指代当前文件的这个仓库 ctx
     */
    async fetchBanner(ctx) {
      if (ctx.state.data.length) {
        //如果仓库的data有值了就不再发出请求了
        return;
      }
     
      ctx.commit('setLoading',true);
      const resp = await getBanners();
      // for(let item of resp){
        // item.bigImg = lostURL + item.bigImg;
        // item.midImg = lostURL + item.midImg;
      // }
     
      ctx.commit('setData',resp)
      ctx.commit('setLoading',false); //数据加载完成改回去
    },
  },
};

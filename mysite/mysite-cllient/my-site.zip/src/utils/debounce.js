//函数防抖
export default (fn, time) => {
  let tm = null;
  return (...parameter) => {
    clearTimeout(tm);
    tm = setTimeout(() => {
      fn(...parameter);
    }, time);
  };
};

<template>
  <Layout>
    <div ref="mainContainer" class="man-container" v-loaing="isLoading">
      <BlogDetail v-if="data" :blob="data" />
      <BlogComment v-if="!isLoading" />
    </div>
    <template #right>
      <div class="right-container" v-loaing="isLoading">
        <BlogTOc :toc="data.toc" v-if="data" />
      </div>
    </template>
  </Layout>
</template>

<script>
import Layout from "@/components/Layout";
import fetchData from "@/mixins/fetchData";
import BlogTOc from "./components/BlogTOC.vue";
import BlogDetail from "./components/BlogDetail.vue";
import { getBlog } from "@/api/blog";
import BlogComment from "./components/BlogComment.vue";
import mainScroll from "@/mixins/mainScroll";
import{titleController} from "@/utils"
export default {
  mixins: [fetchData(null),mainScroll("mainContainer")],
  components: {
    Layout,
    BlogTOc,
    BlogDetail,
    BlogComment,
  },
  methods: {
    async fetchData() {
    let resp = await getBlog(this.$route.params.id);
      if (!resp) {
        // 文章不存在
        this.$router.push("/404");
        return;
      }
     titleController.setRouteTitle(resp.title);
      return resp;
    },
  },
  updated(){
    const hash = location.hash;
    location.hash = "";
    setTimeout(()=>{
      location.hash = hash;
    },50)
  },
};
</script>

<style lang="less" scoped>
.man-container {
  overflow-y: scroll;
  height: 100%;
  box-sizing: border-box;
  padding: 20px;
  position: relative;
  width: 100%;
  overflow-x: hidden;
  scroll-behavior: smooth;
}
.right-container {
  width: 300px;
  height: 100%;
  overflow-y: scroll;
  box-sizing: border-box;
  position: relative;
  padding: 20px;
}
</style>
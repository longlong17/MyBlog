<template>
  <div class="blog-comment-container">
    <MessageArea
      title="评论列表"
      :subTitle="`(${data.total})`"
      :list="data.rows"
      :isListLoading="isLoading"
      @submit="handleSubmit"
    />
  </div>
</template>

<script>
import MessageArea from "@/components/MessageArea";
import fetchData from "@/mixins/fetchData.js";
import { getComments, postComment } from "@/api/blog.js";
import {lostURL} from"@/URL";
export default {
  mixins: [fetchData({ total: 0, rows: [] })],
  components: {
    MessageArea,
  },
  data() {
    return {
      page: 1,
      limit: 10,
    };
  },
  created() {
    this.$bus.$on("mainScroll", this.handleSctoll);
  },
  destroyed(){
    this.$bus.$off("mainScroll", this.handleSctoll);
  },
  computed: {
    hasMore() {
      //还有更多的数据
      return this.data.rows.length < this.data.total;
    },
  },
  methods: {
    handleSctoll(dom) {
      if(this.isLoading || !dom){
        //表示正在加载
        return;
      }
      const rage = 100; //可见的范围
      const dec = Math.abs(dom.scrollTop + dom.clientHeight - dom.scrollHeight);
      if (dec <= rage) {
         this.fetchMore();
      }
    },
    async fetchData() {
      const resp =  await getComments(this.$route.params.id, this.page, this.limit);
      // for(let item of resp.rows){
        // item.avatar = lostURL + item.avatar
      // }
      return resp 
    },
    //加载更多
    async fetchMore() {
      if (!this.hasMore) {
        return;
      }
      this.page++;
      this.isLoading = true;
      const newdata = await this.fetchData();
      this.total = newdata.total;
      this.data.rows = this.data.rows.concat(newdata.rows);
      this.isLoading = false;
    },
    async handleSubmit(formData, callback) {
      const resp = await postComment({
        blogId: this.$route.params.id,
        ...formData,
      });
      // resp.avatar = lostURL + resp.avatar;
      this.data.rows.unshift(resp);
      this.data.total++;
      callback("评论成功"); // 告诉子组件，我这边处理完了，你继续
    },
  },
};
</script>

<style scoped lang="less">
.blog-comment-container {
  margin: 30px 0;
}
</style>

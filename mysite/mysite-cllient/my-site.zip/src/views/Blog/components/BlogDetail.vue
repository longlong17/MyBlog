<template>
  <div class="blog-detail-container">
    <h1>{{ blob.title }}</h1>
    <div class="aside">
      <span>日期：{{ formatData(blob.createDate) }}</span>
      <span>浏览：{{ blob.scanNumber }}</span>
      <a href="#data-form-container">评论：{{ blob.commentNumber }}</a>
      <a href="" v-if="blob.category">{{ blob.category.name }}</a>
    </div>
    <div v-html="blob.htmlContent" class="markdown-body"></div>
  </div>
</template>

<script>
import formatData from "@/utils/formatData";
import "@/style/markdown.css";
import "highlight.js/styles/github.css";
export default {
  methods: {
    formatData,
  },
  props: {
    blob: {
      type: Object,
    },
  },
};
</script>

<style lang="less" scoped>
@import '~@/style/var.less';
.aside {
  span,
  a {
    margin-left: 20px;
    color: @gray;
  }
}
</style>
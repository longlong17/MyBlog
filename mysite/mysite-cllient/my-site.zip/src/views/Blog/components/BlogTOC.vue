<template>
  <div class="blog-toc-container">
    <h2>目录</h2>
    <RightList :list="tocWithSelect" @select="handleSelect" />
  </div>
</template>

<script>
import RightList from "./RightList.vue";
import { debounce } from "@/utils/";
export default {
  components: {
    RightList,
  },
  props: {
    toc: {
      type: Array,
    },
  },
  data() {
    return {
      activeAnchor: "",
    };
  },
  computed: {
    //设置带有激活样式的数组
    tocWithSelect() {
      const getTOC = (toc = []) => {
        return toc.map((t) => ({
          ...t,
          isSelect: t.anchor === this.activeAnchor,
          children: getTOC(t.children),
        }));
      };
      return getTOC(this.toc);
    },
    //得到标题的数组
    doms() {
      const doms = [];
      const addToDoms = (toc) => {
        for (const t of toc) {
          doms.push(document.getElementById(t.anchor));
          if (t.children && t.children.length) {
            addToDoms(t.children);
          }
        }
      };
      addToDoms(this.toc);
      return doms;
    },
  },
  created() {
    this.setSelectDebounce = debounce(this.setSelect, 50);
    this.$bus.$on("mainScroll", this.setSelectDebounce); //让事件总线程去执行这个函数
  },
  destroyed(){
    this.$bus.$off("mainScroll", this.setSelectDebounce);
  },
  
  methods: {
    handleSelect(item) {
      location.hash = item.anchor;
    },
    //设置正确的激活样式
    setSelect(scrollDom) {
      if(!scrollDom){
        return;
      }
      const distance = 200; //h1的位置不能小于这个范围
      this.activeAnchor = "";
      for (const dom of this.doms) {
        //如果没有这个dom跳过本次循环
        if (!dom) {
          continue;
        }
        //如果dom的位置在规定的范围内
        const top = dom.getBoundingClientRect().top;
        if (top <= distance && top >= 0) {
          this.activeAnchor = dom.id;
        } else if (top > distance) {
          //当top的值大于规定的范围什么都不做继续保持
          return;
        } else {
          //在上方
          this.activeAnchor = dom.id;
        }
      }
    },
  },
};
</script>

<style>
.blog-toc-container,
h2 {
  font-weight: bold;
  letter-spacing: 2px;
  font-size: 1em;
  margin: 0;
}
</style>
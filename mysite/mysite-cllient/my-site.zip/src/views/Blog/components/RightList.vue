<template>
  <ul class="right-list-container">
    <li v-for="(item, i) in list" :key="i">
      <span @click="handleClick(item)"  :class="{ active: item.isSelect }">{{ item.name }}</span>
      <span
      v-if="item.aside"
      @click="handleClick(item)" 
      class="aside"
       :class="{ active: item.isSelect }"
      >
      {{ item.aside }}
      </span>
      <RightList :list="item.children" @select="handleClick"/>
    </li>
  </ul>
</template>

<script>
export default {
  //  [{name:'文本',isSelect:true是否选中,children:[{name:'文本',isSelect:true}]}]
  name: "RightList",
  props: {
    list: {
      typeof: Array,
      default: () => [], //如果默认值是对象或者是数组要写成函数返回值的形式
    },
  },
  methods:{
    handleClick(item){
      if(!item.isSelect){
         this.$emit("select", item);
      }
    }
  }
};
</script>

<style lang="less" scoped>
@import '~@/style/var.less';
.right-list-container {
  padding: 0;
  margin: 0;
  list-style: none;
  li {
    min-height: 40px;
    line-height: 40px;
    font-size: 14px;
    cursor: pointer;
    .active{
       color: @warn;
       font-weight: bold;
    }
  }
  .right-list-container {
    margin-left: 1em;
  }
}
.aside {
  font-size: 12px;
  margin-left: 1em;
  color: @gray;
}
</style>
<template>
  <Layout>
    <BlogList />
    <template #right> 
      <BlogCategory />
    </template>
  </Layout>
</template>

<script>
import Layout from '../../components/Layout'   //布局组件
import BlogCategory from './components/BlogCategory.vue'; //右区域
import BlogList from './components/BlogList.vue'; //主区域
export default {
   components: {
    Layout,
    BlogCategory,
    BlogList,
   }
}
</script>

